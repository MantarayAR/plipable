/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports) {

	'use strict';

	var head = document.head,
	    link = document.createElement('link');

	link.type = 'text/css';
	link.rel = 'stylesheet';
	link.href = 'https://fonts.googleapis.com/icon?family=Material+Icons';

	head.appendChild(link);

	var s = document.createElement('script');
	s.src = chrome.extension.getURL('index.js');
	s.onload = function () {
	  this.parentNode.removeChild(this);
	};
	(document.head || document.documentElement).appendChild(s);

	var alreadyAttached = false;
	var injectLoggedInAsUserId = function injectLoggedInAsUserId(response) {
	  var userId = response.userId;
	  var appToken = response.appToken;

	  var actualCode = ['+function() {', 'window.plipableLoginAsUser("' + userId + '", "' + appToken + '");', '}();'].join('\n');

	  var script = document.createElement('script');
	  script.textContent = actualCode;
	  (document.head || document.documentElement).appendChild(script);
	  script.parentNode.removeChild(script);
	};

	var _boot = function _boot() {
	  if (!alreadyAttached) {
	    alreadyAttached = true;

	    document.addEventListener('plipable-login-event', function (e) {
	      chrome.runtime.sendMessage(e, {}, function (response) {
	        injectLoggedInAsUserId(response);
	      });
	    }, false);
	  }
	};

	var observer = new MutationObserver(_boot);
	var config = { attributes: true, childList: true, characterData: true };
	observer.observe(document.getElementById('content'), config);

	_boot();

/***/ }
/******/ ]);