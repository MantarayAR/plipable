Plipable Chrome Extension
=========================

Read the main README!

You need to run `gulp` before the plugin will actually work in chrome!